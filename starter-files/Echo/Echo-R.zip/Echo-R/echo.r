args <- (commandArgs(TRUE))

	print(args)

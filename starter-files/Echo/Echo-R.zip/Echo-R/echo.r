args <- (commandArgs(TRUE))

	cat(args)

Rscript *.r $*


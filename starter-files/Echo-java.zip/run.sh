#!/bin/bash
java main $*






#!/bin/bash
javac -d .  *.java
 

public class main
{
    public static void main (String[] args) 
     {
        for (String s: args) 
         {
            System.out.print(s+' ');
         }
     }
}

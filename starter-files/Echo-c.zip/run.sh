#!/bin/bash
./cexecutable $*

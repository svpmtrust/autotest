#!/bin/bash
gcc *.c -o cexecutable

#!/bin/bash
python *.py $*
